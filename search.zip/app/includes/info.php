<?php

define('SOFTWARE_NAME', 'cybermonks.tech');
define('SOFTWARE_AUTHOR', 'cybermonks');
define('SOFTWARE_URL', 'https://cybermonks.tech');
define('SOFTWARE_VERSION', '1.0.0');