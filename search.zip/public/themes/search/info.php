<?php
// Theme Name
$name = 'cyberMonks Search';

// Theme Author
$author = 'Team CyberMonks';

// Theme URL
$url = 'https://cybermonks.tech/';

// Theme Version
$version = '1.0.0';