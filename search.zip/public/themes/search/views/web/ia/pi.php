<?php
defined('FIR') OR exit();
/**
 * The template for displaying the Pi Instant Answer
 */
?>
<div class="row row-card-result">
    <div class="web-ia web-ia-pi">
        <div class="web-ia-title"><?=$lang['pi_is']?></div>
        <div class="web-ia-content"><?=$data['result']?></div>
    </div>
</div>