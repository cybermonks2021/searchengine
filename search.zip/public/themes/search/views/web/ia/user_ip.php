<?php
defined('FIR') OR exit();
/**
 * The template for displaying the User IP Instant Answer
 */
?>
<div class="row row-card-result">
    <div class="web-ia web-ia-user-ip">
        <div class="web-ia-title"><?=$lang['your_ip_is']?></div>
        <div class="web-ia-content"><?=$data['result']?></div>
    </div>
</div>