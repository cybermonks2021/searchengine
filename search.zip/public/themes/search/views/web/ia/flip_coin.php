<?php
defined('FIR') OR exit();
/**
 * The template for displaying the Flip Coin Instant Answer
 */
?>
<div class="row row-card-result">
    <div class="web-ia web-ia-ip">
        <div class="web-ia-title"><?=$lang['you_have_flipped']?></div>
        <div class="web-ia-content"><?=$data['result']?></div>
    </div>
</div>