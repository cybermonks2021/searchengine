<?php
defined('FIR') OR exit();
/**
 * The template for displaying the token input
 */
?>
<input type="hidden" name="token_id" value="<?=$data['token_id']?>">